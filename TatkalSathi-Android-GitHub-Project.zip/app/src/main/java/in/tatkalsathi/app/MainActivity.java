package in.tatkalsathi.app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView countdown, journeyDateText, savedStatus;
    private Spinner classSpinner;
    private Calendar journey = Calendar.getInstance();
    private Runnable ticker;
    private EditText passengerName, passengerAge, mobile;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("passengers", MODE_PRIVATE);
        buildScreen();
        loadPassenger();
        startTicker();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(12), dp(18), dp(20)); return l;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = column(); root.setBackgroundColor(Color.rgb(246,249,253));
        scroll.addView(root);
        TextView title = text("Tatkal Sathi", 28, Color.WHITE, true);
        TextView subtitle = text("Your Smart Tatkal Booking Assistant", 13, Color.rgb(220,235,255), false);
        LinearLayout hero = column(); hero.setBackgroundColor(Color.rgb(15,75,145));
        hero.addView(title); hero.addView(subtitle);
        root.addView(hero, new LinearLayout.LayoutParams(-1, dp(112)));

        TextView intro = text("Plan faster. Keep passenger details ready.", 16, Color.rgb(25,45,70), true);
        intro.setPadding(0,dp(16),0,dp(8)); root.addView(intro);
        root.addView(text("TATKAL OPENING TIMER",12,Color.rgb(75,95,120),true));
        countdown = text("--:--:--", 34, Color.rgb(15,75,145), true);
        countdown.setPadding(0,dp(6),0,dp(4)); root.addView(countdown);
        root.addView(text("AC: 10:00 AM  •  Sleeper / Non-AC: 11:00 AM",13,Color.DKGRAY,false));
        root.addView(text("Choose travel date",15,Color.rgb(25,45,70),true));
        journeyDateText = text("",16,Color.rgb(15,75,145),true);
        journeyDateText.setPadding(0,dp(8),0,dp(8)); root.addView(journeyDateText);
        Button dateBtn = new Button(this); dateBtn.setText("Select journey date");
        root.addView(dateBtn); dateBtn.setOnClickListener(v -> chooseDate());

        root.addView(text("Ticket class",15,Color.rgb(25,45,70),true));
        classSpinner = new Spinner(this);
        String[] classes = {"AC Tatkal (10:00 AM)", "Sleeper / Non-AC Tatkal (11:00 AM)"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, classes);
        classSpinner.setAdapter(adapter); root.addView(classSpinner);
        classSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { updateTimer(); }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });

        root.addView(text("Saved passenger details",18,Color.rgb(25,45,70),true));
        passengerName = field("Passenger full name");
        passengerAge = field("Age");
        mobile = field("Mobile number");
        root.addView(passengerName); root.addView(passengerAge); root.addView(mobile);
        Button save = new Button(this); save.setText("Save passenger details");
        root.addView(save); savedStatus = text("",13,Color.rgb(20,120,70),false); root.addView(savedStatus);
        save.setOnClickListener(v -> savePassenger());

        TextView note = text("Booking and payment are completed only through IRCTC's official flow. This app does not bypass CAPTCHA, OTP, queue controls or payment authentication.",12,Color.rgb(90,100,115),false);
        note.setPadding(0,dp(16),0,dp(8)); root.addView(note);
        Button irctc = new Button(this); irctc.setText("Open official IRCTC booking");
        root.addView(irctc); irctc.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.irctc.co.in/nget/train-search"));
            startActivity(i);
        });
        setContentView(scroll);
        updateDateLabel();
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint);
        e.setTextSize(15); return e;
    }
    private void chooseDate() {
        Calendar c = (Calendar) journey.clone();
        new DatePickerDialog(this, (view,y,m,d) -> {
            journey.set(y,m,d); updateDateLabel(); updateTimer();
        }, c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void updateDateLabel() {
        journeyDateText.setText(new SimpleDateFormat("EEE, dd MMM yyyy",Locale.getDefault()).format(journey.getTime()));
    }
    private void startTicker() {
        ticker = new Runnable() { public void run() { updateTimer(); handler.postDelayed(this,1000); } };
        handler.post(ticker);
    }
    private void updateTimer() {
        if (countdown == null || classSpinner == null) return;
        Calendar target = (Calendar) journey.clone();
        target.add(Calendar.DAY_OF_YEAR,-1);
        target.set(Calendar.HOUR_OF_DAY, classSpinner.getSelectedItemPosition()==0 ? 10 : 11);
        target.set(Calendar.MINUTE,0); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0);
        long diff = target.getTimeInMillis()-System.currentTimeMillis();
        if (diff <= 0) {
            countdown.setText("Opening time passed");
            return;
        }
        long sec = diff/1000, days=sec/86400, hours=(sec%86400)/3600, mins=(sec%3600)/60, seconds=sec%60;
        countdown.setText(days>0 ? String.format(Locale.getDefault(),"%d d %02d:%02d:%02d",days,hours,mins,seconds)
                : String.format(Locale.getDefault(),"%02d:%02d:%02d",hours,mins,seconds));
    }
    private void savePassenger() {
        String n=passengerName.getText().toString().trim(), a=passengerAge.getText().toString().trim(), m=mobile.getText().toString().trim();
        if(n.isEmpty() || a.isEmpty() || m.isEmpty()) { savedStatus.setText("Please enter name, age and mobile number."); return; }
        prefs.edit().putString("name",n).putString("age",a).putString("mobile",m).apply();
        savedStatus.setText("Passenger details saved on this device.");
    }
    private void loadPassenger() {
        passengerName.setText(prefs.getString("name",""));
        passengerAge.setText(prefs.getString("age",""));
        mobile.setText(prefs.getString("mobile",""));
    }
    @Override protected void onDestroy() {
        super.onDestroy(); if(ticker!=null) handler.removeCallbacks(ticker);
    }
}
