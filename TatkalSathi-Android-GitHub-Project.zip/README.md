# Tatkal Sathi (Android starter)

A simple Android Tatkal assistant prototype for AC and Sleeper/Non-AC classes.

## Included
- Tatkal countdown based on the selected journey date (one day before travel): 10:00 AM for AC and 11:00 AM for Sleeper/Non-AC.
- Local passenger detail save/autofill (name, age, mobile).
- Button to open the official IRCTC train-search website.

## Important limitations
This is an assistant/prototype, not an IRCTC booking client. It does not search live train inventory, submit bookings, automate CAPTCHA/OTP, bypass queues, or process payments. Real ticket booking/payment requires IRCTC-authorized integration and must follow current IRCTC rules. Verify current Tatkal opening rules with IRCTC before travel.

## Build APK using GitHub
1. Create a new GitHub repository.
2. Upload all files and folders from this project (keep the `.github/workflows/build-apk.yml` path).
3. Push to `main` (or `master`).
4. Open the repository's **Actions** tab and select **Build Tatkal Sathi APK**.
5. When the run finishes, open the run and download the **Tatkal-Sathi-debug-apk** artifact.
6. Extract the ZIP; `app-debug.apk` is the installable debug APK. Android may ask you to allow installation from that source.

For a Play Store release, create and protect your own signing key and configure a signed release build. Do not commit signing keys or passwords to GitHub.
